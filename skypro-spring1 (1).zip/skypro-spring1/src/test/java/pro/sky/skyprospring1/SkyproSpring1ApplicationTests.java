package pro.sky.skyprospring1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkyproSpring1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
