package pro.sky.skyprospring1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkyproSpring1Application {

	public static void main(String[] args) {
		SpringApplication.run(SkyproSpring1Application.class, args);
	}

}
